const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(express.static(path.join(__dirname, 'public')));

// תור המתנה - משתמשים שמחפשים שותף
const waitingQueue = [];

// מפת חדרים פעילים: roomId -> { users: [socketId1, socketId2] }
const activeRooms = new Map();

function generateRoomId() {
  return 'room_' + Math.random().toString(36).substring(2, 10);
}

function removeFromQueue(socket) {
  const idx = waitingQueue.indexOf(socket);
  if (idx !== -1) waitingQueue.splice(idx, 1);
}

function leaveCurrentRoom(socket) {
  const roomId = socket.currentRoom;
  if (!roomId) return;

  // הודע לשותף
  socket.to(roomId).emit('partner_left');

  // נקה את החדר
  const room = activeRooms.get(roomId);
  if (room) {
    room.users.forEach((uid) => {
      const s = io.sockets.sockets.get(uid);
      if (s && s.id !== socket.id) {
        s.currentRoom = null;
      }
    });
    activeRooms.delete(roomId);
  }

  socket.leave(roomId);
  socket.currentRoom = null;
}

io.on('connection', (socket) => {
  console.log(`[+] חיבור: ${socket.id}`);
  socket.currentRoom = null;

  // משתמש מחפש שותף
  socket.on('find_partner', () => {
    // אם כבר בחדר - צא קודם
    leaveCurrentRoom(socket);
    removeFromQueue(socket);

    if (waitingQueue.length > 0) {
      // יש מישהו בתור - חבר ביניהם
      const partner = waitingQueue.shift();
      const roomId = generateRoomId();

      socket.join(roomId);
      partner.join(roomId);

      socket.currentRoom = roomId;
      partner.currentRoom = roomId;

      activeRooms.set(roomId, { users: [socket.id, partner.id] });

      // הודע לשניהם
      io.to(roomId).emit('matched', { roomId });
      console.log(`[=] הותאמו: ${socket.id} + ${partner.id} → ${roomId}`);
    } else {
      // אין אחד בתור - הוסף לתור
      waitingQueue.push(socket);
      socket.emit('waiting');
      console.log(`[…] ממתין: ${socket.id} (בתור: ${waitingQueue.length})`);
    }
  });

  // שליחת הודעת טקסט
  socket.on('send_message', (data) => {
    if (!socket.currentRoom) return;
    if (typeof data.text !== 'string') return;

    const text = data.text.trim().substring(0, 1000); // מגבלת תווים
    if (!text) return;

    socket.to(socket.currentRoom).emit('receive_message', {
      text,
      timestamp: Date.now()
    });
  });

  // ניתוק מרצון
  socket.on('skip', () => {
    leaveCurrentRoom(socket);
    socket.emit('skipped');
  });

  // ניתוק מהשרת
  socket.on('disconnect', () => {
    removeFromQueue(socket);
    leaveCurrentRoom(socket);
    console.log(`[-] ניתוק: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 שרת זרים פועל על פורט ${PORT}`);
});
